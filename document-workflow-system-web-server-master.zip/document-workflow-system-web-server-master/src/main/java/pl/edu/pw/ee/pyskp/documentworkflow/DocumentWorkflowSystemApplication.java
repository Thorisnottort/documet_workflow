package pl.edu.pw.ee.pyskp.documentworkflow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocumentWorkflowSystemApplication {
    public static void main(String[] args) {
        SpringApplication.run(DocumentWorkflowSystemApplication.class, args);
    }
}
