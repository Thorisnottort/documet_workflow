# Document-workflow-system web-server

Projekt powstał w ramach mojej pracy inżynierskiej o pt.:
_System obiegu dokumentów wspomagający prowadzenie projektów badawczych._

W ramach pracy magisterskiej wymieniona została baza danych z PostgreSQL na MongoDB.

## Przeznaczenie

Jest to system, który pomaga prowadzić dokumentację projektów badawczych.
Podstawowymi problemami, które taki system rozwiązuje są:

* śledzenie, kto i jakie zmiany wykonał,
* śledzenie, która wersja jest aktualna/najnowsza.

Ten projekt jest **serwerem aplikacyjnym** całego systemu.
